# Run v13_glossary_pt50_20261004

Trạng thái: **running** (tự sinh bởi `python -m docmt run`; owner cập nhật sau khi kiểm).

- Branch: `hy_a1_structure` — backend: `hf` — owner: Lam
- Thời điểm bắt đầu (UTC; team UTC+7): 2026-10-04T07:39:35Z
- Manifest: `None` (sha256 `96c96d30b0ae33cff578244affc2c0facbc114393c8aa28cfcc5f36793ac10bf`)
- Hướng: en-vi
- Config: `run_config.json` (sha256 `f0beedd9752f513c71f7557cc3dd32e244316b2d42160eb697f4617b2d635e39`)

## Cấu trúc

- `predictions/<hướng>/<category>/<id>.md`: Markdown dịch (không marker nội bộ, không diagnostics).
- `logs/<hướng>.run.json`: metadata run; `logs/generation_trace.jsonl`: một bản ghi mỗi request;
  `logs/prompts.jsonl`: prompt theo sha256; `logs/document_status.jsonl`; `logs/runtime_errors.jsonl`;
  `logs/cache.jsonl`: cache resume.
- `tests/parser_roundtrip.json`, `tests/smoke_result.csv`.

## Lưu ý

- Chỉ đọc nguồn khi sinh; reference không được đọc. Cảnh báo tự động là `needs_review`, không phải
  kết luận sai nghĩa. Chưa có review nghĩa thì ghi `not_checked`.
- Metric/thời gian/VRAM chỉ ghi khi đã đo (xem run.json).
