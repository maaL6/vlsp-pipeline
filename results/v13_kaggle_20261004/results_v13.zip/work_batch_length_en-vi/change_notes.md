# Change notes — v13_batch_length_pt50_20261004

Trạng thái: **not_checked** (stub tự sinh; owner điền).

- So với run trước / nhánh gốc: (chưa điền)
- Thay đổi config (một thành phần mỗi ablation): (chưa điền)
- Đã sửa / chưa sửa: (chưa điền)
