# Run hy_a1_structure__pt50__kaggleT4__20261004

Trạng thái: **running** (tự sinh bởi `python -m docmt run`; owner cập nhật sau khi kiểm).

- Branch: `hy_a1_structure` — backend: `hf` — owner: Lam
- Thời điểm bắt đầu (UTC; team UTC+7): 2026-10-03T18:15:29Z
- Manifest: `None` (sha256 `c2394072eae1b80d81552e51291149f92c484d1d1f2b18aa94230c8c7a76cd4a`)
- Hướng: vi-en
- Config: `run_config.json` (sha256 `4c699e56ecfb69c4a0c564f328f18c59626762c01519be3335f2ebd86dc45c22`)

## Cấu trúc

- `predictions/<hướng>/<category>/<id>.md`: Markdown dịch (không marker nội bộ, không diagnostics).
- `logs/<hướng>.run.json`: metadata run; `logs/generation_trace.jsonl`: một bản ghi mỗi request;
  `logs/prompts.jsonl`: prompt theo sha256; `logs/document_status.jsonl`; `logs/runtime_errors.jsonl`;
  `logs/cache.jsonl`: cache resume.
- `tests/parser_roundtrip.json`, `tests/smoke_result.csv`.

## Lưu ý

- Chỉ đọc nguồn khi sinh; reference không được đọc. Cảnh báo tự động là `needs_review`, không phải
  kết luận sai nghĩa. Chưa có review nghĩa thì ghi `not_checked`.
- Metric/thời gian/VRAM chỉ ghi khi đã đo (xem run.json).
